/**
 * canvasRenderer.js
 *
 * Pure Canvas2D drawing functions. Every function takes an explicit
 * canvasWidth/canvasHeight so the exact same code path renders the small
 * live preview and every full-resolution export target — the layout math
 * never branches on a specific resolution.
 */

// ---------------------------------------------------------------------------
// Layer 1 — Background ("object-fit: cover" equivalent)
// ---------------------------------------------------------------------------

/**
 * Draws `img` to fill the entire canvas, cropping (never stretching) to
 * preserve the source aspect ratio — the canvas equivalent of CSS
 * `object-fit: cover`.
 */
export function drawBackgroundCover(ctx, img, canvasW, canvasH) {
  if (!img) {
    ctx.fillStyle = "#0B0E11";
    ctx.fillRect(0, 0, canvasW, canvasH);
    return;
  }

  const sourceRatio = img.width / img.height;
  const targetRatio = canvasW / canvasH;

  let sx, sy, sWidth, sHeight;

  if (sourceRatio > targetRatio) {
    // Source is relatively wider than target -> crop left/right
    sHeight = img.height;
    sWidth = sHeight * targetRatio;
    sx = (img.width - sWidth) / 2;
    sy = 0;
  } else {
    // Source is relatively taller than target -> crop top/bottom
    sWidth = img.width;
    sHeight = sWidth / targetRatio;
    sx = 0;
    sy = (img.height - sHeight) / 2;
  }

  ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, canvasW, canvasH);
}

// ---------------------------------------------------------------------------
// Layer 2 — Overlay image (right-anchored, 25% canvas width, ratio-locked)
// ---------------------------------------------------------------------------

/**
 * Draws the overlay image flush against the right edge. Width is locked to
 * exactly 25% of canvas width; height is derived from the source's own
 * aspect ratio so it is never squished or stretched. Vertically centered.
 */
export function drawOverlayRight(ctx, img, canvasW, canvasH) {
  if (!img) return;

  const drawW = canvasW * 0.25;
  const drawH = drawW * (img.height / img.width);

  const x = canvasW - drawW;
  const y = (canvasH - drawH) / 2;

  ctx.drawImage(img, x, y, drawW, drawH);
}

// ---------------------------------------------------------------------------
// Layer 3 — Title text (left-anchored, 65% max width, word-wrapped)
// ---------------------------------------------------------------------------

const TITLE_LEFT_PADDING_PCT = 0.05;
const TITLE_MAX_WIDTH_PCT = 0.65;
const TITLE_BASE_FONT_PCT = 0.09; // starting font size as a fraction of canvas height
const TITLE_LINE_HEIGHT_MULT = 1.18;
const TITLE_MIN_FONT_PX = 10;

/** Breaks `text` into lines that each fit within `maxWidth` for the current ctx.font. */
function wrapText(ctx, text, maxWidth) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let current = "";

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (ctx.measureText(candidate).width <= maxWidth || !current) {
      current = candidate;
    } else {
      lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);
  return lines;
}

/**
 * Draws the title, vertically centered, wrapped within the 65%-width /
 * 5%-left-padding box. Font size starts proportional to canvas height and
 * is scaled down (preserving the same proportional relationship, never
 * stretched) until the wrapped block fits the available vertical space.
 */
export function drawTitleText(ctx, text, canvasW, canvasH, options = {}) {
  if (!text || !text.trim()) return;

  const {
    fontFamily = "Inter, system-ui, sans-serif",
    color = "#FFFFFF",
    fontWeight = 700,
    align = "left",
  } = options;

  const paddingLeft = canvasW * TITLE_LEFT_PADDING_PCT;
  const maxWidth = canvasW * TITLE_MAX_WIDTH_PCT;
  const maxHeight = canvasH * 0.8; // leave headroom top/bottom

  let fontSize = Math.max(TITLE_MIN_FONT_PX, canvasH * TITLE_BASE_FONT_PCT);
  let lines = [];

  // Shrink-to-fit: reduce font size proportionally until the wrapped block
  // fits both the width box and the vertical headroom.
  for (let i = 0; i < 24; i++) {
    ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
    lines = wrapText(ctx, text, maxWidth);
    const blockHeight = lines.length * fontSize * TITLE_LINE_HEIGHT_MULT;
    if (blockHeight <= maxHeight || fontSize <= TITLE_MIN_FONT_PX) break;
    fontSize *= 0.92;
  }

  ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = "middle";

  const lineHeight = fontSize * TITLE_LINE_HEIGHT_MULT;
  const blockHeight = lines.length * lineHeight;
  const startY = canvasH / 2 - blockHeight / 2 + lineHeight / 2;
  const x = align === "left" ? paddingLeft : paddingLeft + maxWidth / 2;

  lines.forEach((line, i) => {
    ctx.fillText(line, x, startY + i * lineHeight);
  });
}

// ---------------------------------------------------------------------------
// Layer 4 — Logo (top-right, 5% margin, 10% canvas width, ratio-locked)
// ---------------------------------------------------------------------------

export function drawLogo(ctx, img, canvasW, canvasH) {
  if (!img) return;

  const margin = canvasW * 0.05;
  const drawW = canvasW * 0.1;
  const drawH = drawW * (img.height / img.width); // aspect ratio strictly preserved

  const x = canvasW - margin - drawW;
  const y = margin;

  ctx.drawImage(img, x, y, drawW, drawH);
}

// ---------------------------------------------------------------------------
// Layer 5 — Extra PNG overlays (center by default, or custom X/Y%)
// ---------------------------------------------------------------------------

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {{ img: HTMLImageElement, xPct: number, yPct: number, widthPct: number }[]} extras
 *   xPct/yPct: 0-100, position of the image's *center* as a percentage of
 *   canvas width/height. widthPct: image width as a percentage of canvas
 *   width; height is always derived from the source aspect ratio.
 */
export function drawExtraPngs(ctx, extras, canvasW, canvasH) {
  if (!extras || extras.length === 0) return;

  for (const extra of extras) {
    const { img, xPct = 50, yPct = 50, widthPct = 20 } = extra;
    if (!img) continue;

    const drawW = canvasW * (widthPct / 100);
    const drawH = drawW * (img.height / img.width);

    const centerX = canvasW * (xPct / 100);
    const centerY = canvasH * (yPct / 100);

    ctx.drawImage(img, centerX - drawW / 2, centerY - drawH / 2, drawW, drawH);
  }
}

// ---------------------------------------------------------------------------
// Orchestrator — draws every layer, in order, for one canvas
// ---------------------------------------------------------------------------

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} canvasW
 * @param {number} canvasH
 * @param {{
 *   background: HTMLImageElement | null,
 *   overlay: HTMLImageElement | null,
 *   logo: HTMLImageElement | null,
 *   extras: Array<{img: HTMLImageElement, xPct: number, yPct: number, widthPct: number}>,
 *   title: string,
 *   fontFamily: string,
 *   textColor: string,
 * }} assets
 */
export function renderComposite(ctx, canvasW, canvasH, assets) {
  const { background, overlay, logo, extras, title, fontFamily, textColor } = assets;

  ctx.clearRect(0, 0, canvasW, canvasH);

  drawBackgroundCover(ctx, background, canvasW, canvasH);
  drawOverlayRight(ctx, overlay, canvasW, canvasH);
  drawExtraPngs(ctx, extras, canvasW, canvasH);
  drawTitleText(ctx, title, canvasW, canvasH, { fontFamily, color: textColor });
  drawLogo(ctx, logo, canvasW, canvasH); // always topmost so it's never obscured
}
