import React, { useMemo, useState } from "react";
import Sidebar from "./components/Sidebar";
import PreviewCanvas from "./components/PreviewCanvas";
import ResolutionPanel from "./components/ResolutionPanel";
import { useImageAsset, loadImageFromFile } from "./utils/useImageAsset";
import { loadCustomFont, DEFAULT_FONT_FAMILY } from "./utils/fontLoader";
import { EXPORT_PROFILES } from "./utils/exportProfiles";
import { exportProfilesToZip, downloadBlob } from "./utils/batchExport";

let extraIdCounter = 0;

export default function App() {
  // --- Layer 1/2/4 single-image assets -------------------------------
  const [backgroundFile, setBackgroundFile] = useState(null);
  const [overlayFile, setOverlayFile] = useState(null);
  const [logoFile, setLogoFile] = useState(null);

  const backgroundImg = useImageAsset(backgroundFile);
  const overlayImg = useImageAsset(overlayFile);
  const logoImg = useImageAsset(logoFile);

  // --- Layer 5: extra PNG overlays ------------------------------------
  // Each extra: { id, file, img, previewUrl, xPct, yPct, widthPct }
  const [extras, setExtras] = useState([]);

  const handleAddExtras = async (fileList) => {
    const files = Array.from(fileList);
    const loaded = await Promise.all(
      files.map(async (file) => {
        const { img, objectUrl } = await loadImageFromFile(file);
        return {
          id: `extra-${extraIdCounter++}`,
          file,
          img,
          previewUrl: objectUrl,
          xPct: 50,
          yPct: 50,
          widthPct: 20,
        };
      })
    );
    setExtras((prev) => [...prev, ...loaded]);
  };

  const handleUpdateExtra = (id, patch) => {
    setExtras((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)));
  };

  const handleRemoveExtra = (id) => {
    setExtras((prev) => {
      const target = prev.find((e) => e.id === id);
      if (target) URL.revokeObjectURL(target.previewUrl);
      return prev.filter((e) => e.id !== id);
    });
  };

  // --- Layer 3: title text ---------------------------------------------
  const [title, setTitle] = useState("Breaking News Headline Goes Here");
  const [textColor, setTextColor] = useState("#FFFFFF");

  // --- Custom font -------------------------------------------------------
  const [fontFamily, setFontFamily] = useState(DEFAULT_FONT_FAMILY);
  const [fontFileName, setFontFileName] = useState(null);

  const handleSetFont = async (file) => {
    if (!file) {
      setFontFamily(DEFAULT_FONT_FAMILY);
      setFontFileName(null);
      return;
    }
    const familyName = await loadCustomFont(file);
    setFontFamily(familyName);
    setFontFileName(file.name);
  };

  // --- Resolution selection ---------------------------------------------
  const [selectedIds, setSelectedIds] = useState(
    () => new Set(EXPORT_PROFILES.map((p) => p.id))
  );

  const toggleProfile = (id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleGroup = (profiles, checked) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      profiles.forEach((p) => (checked ? next.add(p.id) : next.delete(p.id)));
      return next;
    });
  };

  // --- Export -------------------------------------------------------------
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0, label: "" });

  // Bundle of everything the renderer needs, memoized so the preview only
  // redraws when an actual visual input changes.
  const assets = useMemo(
    () => ({
      background: backgroundImg,
      overlay: overlayImg,
      logo: logoImg,
      extras: extras.map((e) => ({
        img: e.img,
        xPct: e.xPct,
        yPct: e.yPct,
        widthPct: e.widthPct,
      })),
      title,
      fontFamily,
      textColor,
    }),
    [backgroundImg, overlayImg, logoImg, extras, title, fontFamily, textColor]
  );

  const handleExport = async () => {
    const profiles = EXPORT_PROFILES.filter((p) => selectedIds.has(p.id));
    if (profiles.length === 0) return;

    setIsExporting(true);
    setProgress({ done: 0, total: profiles.length, label: "Starting…" });

    try {
      const zipBlob = await exportProfilesToZip(profiles, assets, (done, total, label) =>
        setProgress({ done, total, label })
      );
      downloadBlob(zipBlob, "thumbnail-batch-export.zip");
    } catch (err) {
      console.error(err);
      alert("Export failed — check the console for details.");
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="h-screen w-screen flex bg-console-bg text-console-text font-sans overflow-hidden">
      <Sidebar
        background={{ file: backgroundFile, previewUrl: backgroundImg?.src }}
        overlay={{ file: overlayFile, previewUrl: overlayImg?.src }}
        logo={{ file: logoFile, previewUrl: logoImg?.src }}
        extras={extras}
        title={title}
        textColor={textColor}
        fontFamily={fontFamily}
        fontFileName={fontFileName}
        onSetBackground={setBackgroundFile}
        onSetOverlay={setOverlayFile}
        onSetLogo={setLogoFile}
        onAddExtras={handleAddExtras}
        onUpdateExtra={handleUpdateExtra}
        onRemoveExtra={handleRemoveExtra}
        onSetTitle={setTitle}
        onSetTextColor={setTextColor}
        onSetFont={handleSetFont}
      />

      <PreviewCanvas assets={assets} />

      <ResolutionPanel
        selectedIds={selectedIds}
        onToggleProfile={toggleProfile}
        onToggleGroup={toggleGroup}
        isExporting={isExporting}
        progress={progress}
        onExport={handleExport}
      />
    </div>
  );
}
