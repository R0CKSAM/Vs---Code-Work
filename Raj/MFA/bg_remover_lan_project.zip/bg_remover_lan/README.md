# Office AI Background Remover (LAN)

A browser-based LAN version of the original Tkinter background remover. The server uses `rembg` with the `u2net` model and returns transparent PNG files at the input image resolution.

## Features

- Browser UI; no software install needed on client computers
- Drag and drop
- JPG / JPEG / PNG / WEBP
- Single image before/after preview
- Transparent PNG download
- Batch processing (default: up to 20 images)
- Batch ZIP download
- Preserves original image dimensions
- One shared U2Net session for faster repeat processing
- Health endpoint at `/health`
- LAN binding on `0.0.0.0:8000`
- Responsive desktop/mobile interface
- Windows setup/start scripts

## Recommended server PC

For a small office, use the strongest available Windows PC. CPU mode works; a modern multi-core CPU and 16 GB RAM is a comfortable starting point. Multiple simultaneous users share the same server hardware, so very large images or heavy concurrent use can take longer.

## Windows setup

1. Install Python 3.11 or 3.12 from python.org. During setup enable **Add Python to PATH**.
2. Extract this project to a permanent folder on the server PC.
3. Double-click `start_server.bat`.
4. On the first run, dependencies and the U2Net model may need to be downloaded.
5. The terminal prints both addresses, for example:

   Local: `http://127.0.0.1:8000`
   LAN: `http://192.168.1.25:8000`

6. Open the LAN address from another PC connected to the same office LAN/Wi-Fi.

## Windows Firewall

If another PC cannot connect:

1. Right-click `open_firewall_port_8000.bat`.
2. Select **Run as administrator**.
3. Keep the server terminal running.
4. Make sure Windows network profile / office router allows devices on the LAN to communicate with each other.

## Fixed LAN address (recommended)

The server PC's IP can change after a restart. For a reliable office URL, configure a DHCP reservation for the server PC in the office router, or assign it a suitable static LAN IP according to your IT policy.

Then staff can bookmark a stable URL such as `http://192.168.1.25:8000`.

## Configuration

Environment variables supported by `app.py`:

- `PORT` — default `8000`
- `MAX_FILE_MB` — default `35`
- `MAX_BATCH` — default `20`
- `REMBG_MODEL` — default `u2net`

Example before starting manually:

```bat
set MAX_BATCH=30
set MAX_FILE_MB=50
set PORT=8000
python app.py
```

## Manual start

```bat
cd path\to\bg_remover_lan
.venv\Scripts\activate
python app.py
```

## Folder layout

```text
bg_remover_lan/
├─ app.py
├─ requirements.txt
├─ start_server.bat
├─ install_only.bat
├─ open_firewall_port_8000.bat
├─ README.md
├─ templates/
│  └─ index.html
├─ static/
│  ├─ style.css
│  └─ app.js
├─ outputs/
└─ temp/
```

## Office/security note

This version is intended for a trusted internal LAN. It has no login/authentication layer. Do not expose port 8000 directly to the public internet. If external access is ever required, add authentication and use a proper HTTPS reverse proxy or VPN.
