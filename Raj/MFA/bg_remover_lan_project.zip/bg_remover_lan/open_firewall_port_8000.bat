@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Please right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
netsh advfirewall firewall add rule name="Office Background Remover 8000" dir=in action=allow protocol=TCP localport=8000
if %errorlevel% equ 0 (
  echo Windows Firewall port 8000 is now allowed.
) else (
  echo Could not add the firewall rule.
)
pause
