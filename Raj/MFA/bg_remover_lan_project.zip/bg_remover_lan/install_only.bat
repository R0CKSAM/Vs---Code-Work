@echo off
setlocal
cd /d "%~dp0"
python -m venv .venv
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Installation complete. Run start_server.bat to launch the app.
pause
