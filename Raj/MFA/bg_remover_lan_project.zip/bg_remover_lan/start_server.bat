@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   Office AI Background Remover - LAN
 echo ==========================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or 3.12 and enable "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
pip install -r requirements.txt

echo.
echo Starting server...
python app.py
pause
