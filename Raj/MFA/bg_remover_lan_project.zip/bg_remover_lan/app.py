import io
import os
import socket
import uuid
import zipfile
from pathlib import Path
from threading import Lock
from typing import List

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image
from rembg import new_session, remove

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "outputs"
TEMP_DIR = BASE_DIR / "temp"
OUTPUT_DIR.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
MAX_FILE_MB = int(os.getenv("MAX_FILE_MB", "35"))
MAX_BATCH = int(os.getenv("MAX_BATCH", "20"))
MODEL_NAME = os.getenv("REMBG_MODEL", "u2net")

app = FastAPI(title="Office AI Background Remover", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")

_session = None
_session_lock = Lock()


def get_session():
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                _session = new_session(MODEL_NAME)
    return _session


def safe_stem(filename: str) -> str:
    stem = Path(filename or "image").stem
    cleaned = "".join(c for c in stem if c.isalnum() or c in ("-", "_", " ")).strip()
    return cleaned[:80] or "image"


def validate_upload(upload: UploadFile, data: bytes):
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Unsupported format: {suffix or 'unknown'}")
    if len(data) > MAX_FILE_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"{upload.filename} exceeds {MAX_FILE_MB} MB")


def process_bytes(data: bytes) -> Image.Image:
    try:
        with Image.open(io.BytesIO(data)) as img:
            img = img.convert("RGBA")
            original_size = img.size
            result = remove(img, session=get_session())
            if result.size != original_size:
                result = result.resize(original_size, Image.Resampling.LANCZOS)
            return result.convert("RGBA")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not process image: {exc}") from exc


def image_to_png_bytes(image: Image.Image) -> bytes:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG", optimize=True)
    return buffer.getvalue()


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "max_file_mb": MAX_FILE_MB,
            "max_batch": MAX_BATCH,
            "model_name": MODEL_NAME,
        },
    )


@app.get("/health")
async def health():
    return {"status": "ok", "model": MODEL_NAME}


@app.post("/api/remove")
async def remove_single(file: UploadFile = File(...)):
    data = await file.read()
    validate_upload(file, data)
    result = process_bytes(data)
    png = image_to_png_bytes(result)
    output_name = f"{safe_stem(file.filename)}_no_bg.png"
    return StreamingResponse(
        io.BytesIO(png),
        media_type="image/png",
        headers={
            "Content-Disposition": f'attachment; filename="{output_name}"',
            "X-Output-Filename": output_name,
        },
    )


@app.post("/api/remove-batch")
async def remove_batch(files: List[UploadFile] = File(...)):
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    if len(files) > MAX_BATCH:
        raise HTTPException(status_code=400, detail=f"Maximum {MAX_BATCH} files per batch")

    zip_buffer = io.BytesIO()
    errors = []
    used_names = set()

    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for index, upload in enumerate(files, start=1):
            try:
                data = await upload.read()
                validate_upload(upload, data)
                result = process_bytes(data)
                base = f"{safe_stem(upload.filename)}_no_bg"
                name = f"{base}.png"
                counter = 2
                while name.lower() in used_names:
                    name = f"{base}_{counter}.png"
                    counter += 1
                used_names.add(name.lower())
                zf.writestr(name, image_to_png_bytes(result))
            except Exception as exc:
                detail = getattr(exc, "detail", str(exc))
                errors.append(f"{upload.filename}: {detail}")

        if errors:
            zf.writestr("errors.txt", "\n".join(errors))

    zip_buffer.seek(0)
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="background_removed_images.zip"'},
    )


def get_lan_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except Exception:
        return "127.0.0.1"


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8000"))
    print("\nOffice AI Background Remover")
    print(f"Local:   http://127.0.0.1:{port}")
    print(f"LAN:     http://{get_lan_ip()}:{port}")
    print("Press Ctrl+C to stop.\n")
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
