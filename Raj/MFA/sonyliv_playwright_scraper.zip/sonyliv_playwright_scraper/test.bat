@echo off
setlocal
".venv\Scripts\python.exe" -m pytest -q
pause
