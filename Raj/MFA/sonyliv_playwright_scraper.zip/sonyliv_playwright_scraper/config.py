import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
AUTH_DIR = BASE_DIR / "auth"
DATA_DIR = BASE_DIR / "data"
SCREENSHOT_DIR = BASE_DIR / "screenshots"

AUTH_STATE = AUTH_DIR / "sonyliv_state.json"
JSON_OUTPUT = DATA_DIR / "sonyliv_data.json"
CSV_OUTPUT = DATA_DIR / "sonyliv_data.csv"

SONYLIV_HOME = os.getenv("SONYLIV_HOME", "https://www.sonyliv.com/")
TARGET_URL = os.getenv("TARGET_URL", SONYLIV_HOME)

HEADLESS = os.getenv("HEADLESS", "false").strip().lower() == "true"

for directory in (AUTH_DIR, DATA_DIR, SCREENSHOT_DIR):
    directory.mkdir(parents=True, exist_ok=True)
