import csv
import json
from datetime import datetime, timezone
from typing import Any

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

from config import AUTH_STATE, CSV_OUTPUT, JSON_OUTPUT, TARGET_URL


def clean(value: str | None) -> str:
    return " ".join((value or "").split())


def unique(items: list[str]) -> list[str]:
    seen = set()
    result = []
    for item in items:
        item = clean(item)
        if item and item not in seen:
            seen.add(item)
            result.append(item)
    return result


def scrape_page(page) -> dict[str, Any]:
    page.wait_for_load_state("domcontentloaded")

    try:
        page.wait_for_load_state("networkidle", timeout=10_000)
    except PlaywrightTimeoutError:
        pass

    title = clean(page.title())
    url = page.url

    meta_description = clean(
        page.locator('meta[name="description"]').first.get_attribute("content")
    )

    headings = unique(
        page.locator("h1, h2, h3").all_inner_texts()
    )

    links = []
    for link in page.locator("a[href]").all():
        try:
            text_value = clean(link.inner_text())
            href = link.get_attribute("href") or ""
            if href:
                links.append({"text": text_value, "href": href})
        except Exception:
            continue

    images = []
    for image in page.locator("img[src]").all():
        try:
            src = image.get_attribute("src") or ""
            alt = clean(image.get_attribute("alt"))
            if src:
                images.append({"alt": alt, "src": src})
        except Exception:
            continue

    json_ld = []
    for script in page.locator('script[type="application/ld+json"]').all():
        try:
            raw = script.inner_text()
            if raw.strip():
                json_ld.append(json.loads(raw))
        except Exception:
            # Some sites contain malformed/non-standard JSON-LD.
            continue

    visible_text = clean(page.locator("body").inner_text())

    return {
        "scraped_at_utc": datetime.now(timezone.utc).isoformat(),
        "title": title,
        "url": url,
        "meta_description": meta_description,
        "headings": headings,
        "links": links,
        "images": images,
        "json_ld": json_ld,
        "visible_text": visible_text,
    }


def save_json(data: dict[str, Any]) -> None:
    JSON_OUTPUT.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def save_csv(data: dict[str, Any]) -> None:
    # One row containing page-level fields; complex lists are JSON encoded.
    row = {
        "scraped_at_utc": data["scraped_at_utc"],
        "title": data["title"],
        "url": data["url"],
        "meta_description": data["meta_description"],
        "headings": json.dumps(data["headings"], ensure_ascii=False),
        "links": json.dumps(data["links"], ensure_ascii=False),
        "images": json.dumps(data["images"], ensure_ascii=False),
        "json_ld": json.dumps(data["json_ld"], ensure_ascii=False),
        "visible_text": data["visible_text"],
    }

    with CSV_OUTPUT.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=row.keys())
        writer.writeheader()
        writer.writerow(row)


def main() -> None:
    if not AUTH_STATE.exists():
        raise SystemExit(
            "No saved login session found. Run `python auth.py` first."
        )

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context(storage_state=str(AUTH_STATE))
        page = context.new_page()

        print(f"Opening target: {TARGET_URL}")
        page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=60_000)

        # Give client-rendered content a short opportunity to appear.
        page.wait_for_timeout(3_000)

        data = scrape_page(page)
        save_json(data)
        save_csv(data)

        print("\nScrape completed.")
        print(f"Title : {data['title']}")
        print(f"URL   : {data['url']}")
        print(f"H1-H3 : {len(data['headings'])}")
        print(f"Links : {len(data['links'])}")
        print(f"Images: {len(data['images'])}")
        print(f"JSON  : {JSON_OUTPUT}")
        print(f"CSV   : {CSV_OUTPUT}")

        browser.close()


if __name__ == "__main__":
    main()
