from pathlib import Path

from playwright.sync_api import sync_playwright

from config import AUTH_STATE, SONYLIV_HOME


def main() -> None:
    AUTH_STATE.parent.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        print(f"Opening: {SONYLIV_HOME}")
        page.goto(SONYLIV_HOME, wait_until="domcontentloaded", timeout=60_000)

        print("\nComplete SonyLIV login manually in the browser.")
        print("Handle OTP/CAPTCHA/security checks yourself if shown.")
        input("\nAfter you are fully logged in, press ENTER here... ")

        context.storage_state(path=str(AUTH_STATE))
        print(f"\nSaved authenticated browser state to: {AUTH_STATE}")

        browser.close()


if __name__ == "__main__":
    main()
