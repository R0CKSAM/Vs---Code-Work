@echo off
setlocal

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found.
    echo Run setup first:
    echo   py -m venv .venv
    echo   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
    echo   .\.venv\Scripts\python.exe -m playwright install chromium
    exit /b 1
)

".venv\Scripts\python.exe" scraper.py
pause
