import pytest
from playwright.sync_api import BrowserContext, Page, sync_playwright

from config import AUTH_STATE, TARGET_URL


@pytest.fixture(scope="session")
def browser_context():
    if not AUTH_STATE.exists():
        pytest.skip(
            "No authenticated state. Run `python auth.py` first."
        )

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(storage_state=str(AUTH_STATE))
        yield context
        context.close()
        browser.close()


@pytest.fixture
def page(browser_context: BrowserContext) -> Page:
    page = browser_context.new_page()
    yield page
    page.close()


@pytest.fixture
def target_url() -> str:
    return TARGET_URL
