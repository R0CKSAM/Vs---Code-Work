from config import SCREENSHOT_DIR


def test_sonyliv_page_loads(page, target_url):
    response = page.goto(
        target_url,
        wait_until="domcontentloaded",
        timeout=60_000,
    )

    assert response is not None
    assert response.status < 400
    assert page.url.startswith("http")
    assert page.title().strip()


def test_page_has_body(page, target_url):
    page.goto(
        target_url,
        wait_until="domcontentloaded",
        timeout=60_000,
    )

    body = page.locator("body")
    assert body.count() == 1

    text = body.inner_text().strip()
    assert len(text) > 0


def test_no_obvious_page_error(page, target_url):
    page.goto(
        target_url,
        wait_until="domcontentloaded",
        timeout=60_000,
    )

    body_text = page.locator("body").inner_text().lower()

    # This is deliberately conservative: it does not assume a particular
    # application layout and only catches obvious generic error pages.
    error_markers = [
        "502 bad gateway",
        "503 service unavailable",
        "504 gateway timeout",
    ]

    assert not any(marker in body_text for marker in error_markers), (
        f"Possible server error detected. URL: {page.url}"
    )


def test_screenshot_on_demand(page, target_url):
    # Useful as a visual smoke test while developing selectors.
    page.goto(
        target_url,
        wait_until="domcontentloaded",
        timeout=60_000,
    )
    page.screenshot(
        path=str(SCREENSHOT_DIR / "sonyliv_smoke.png"),
        full_page=True,
    )
