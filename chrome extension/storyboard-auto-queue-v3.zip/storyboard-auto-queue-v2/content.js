// Storyboard Auto Queue v3: explicit state machine; never re-sends a pending frame.
(() => {
 if (window.__storyboardQueueV3) return;
 window.__storyboardQueueV3 = true;
 const CHECK_MS=1800, SETTLE_MS=5500, MAX_WAIT_MS=12*60*1000;
 let tickTimer=null, busy=false;
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const get=()=>chrome.storage.local.get(['master','prompts','index','phase','pending','error','tabId']);
 const set=o=>chrome.storage.local.set(o);
 const all=s=>Array.from(document.querySelectorAll(s));
 const visible=e=>!!(e&&e.isConnected&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden');
 const editor=()=>all('#prompt-textarea,[data-testid="prompt-textarea"],[contenteditable="true"][role="textbox"],textarea').find(visible);
 const userNodes=()=>all('[data-message-author-role="user"]');
 const assistantNodes=()=>all('[data-message-author-role="assistant"]');
 const composerEmpty=e=>!((e.innerText||e.value||'').trim());
 const stopVisible=()=>all('button[data-testid="stop-button"],button[aria-label*="Stop generating"],button[aria-label*="Stop streaming"],button[aria-label="Stop"]').some(visible);
 function sendButton(){
   return all('button[data-testid="send-button"],button[data-testid="composer-send-button"],button[data-testid*="send"],button[aria-label="Send prompt"],button[aria-label="Send message"],button[aria-label="Send"],button[title="Send prompt"],button[title="Send message"],form button[type="submit"]').find(b=>{
     const txt=[b.getAttribute('data-testid'),b.getAttribute('aria-label'),b.title].join(' ').toLowerCase();
     return visible(b)&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'&&!/stop|audio|voice|cancel|microphone/.test(txt)&&(/send|submit/.test(txt)||b.type==='submit'&&b.closest('form'));
   });
 }
 function assets(root){
   // More inclusive than counting assistant <img> tags alone: generated assets can be in nested wrappers.
   const matches=[...root.querySelectorAll('img,video,canvas,[style*="background-image"]')];
   return matches.filter(visible).map(e=>{
     if(e.tagName==='IMG')return `img:${e.currentSrc||e.src||e.getAttribute('src')||''}`;
     if(e.tagName==='VIDEO')return `video:${e.currentSrc||e.src||''}`;
     if(e.tagName==='CANVAS')return `canvas:${e.width}x${e.height}`;
     return `bg:${getComputedStyle(e).backgroundImage}`;
   }).filter(Boolean);
 }
 function snapshot(){
   const msgs=assistantNodes();
   return {assistantCount:msgs.length, assets:msgs.flatMap(assets)};
 }
 function responseStatus(p){
   const snap=snapshot(), a=snap.assets, previous=p.base.assets||[];
   const newer=a.length>previous.length || a.some(x=>!previous.includes(x));
   const newerAssistant=snap.assistantCount>(p.base.assistantCount||0);
   // Scope this check to assistant turns, not uploaded user reference images.
   const last=assistantNodes().slice(-1)[0];
   const lastAssets=last?assets(last):[];
   const imgReady=last?[...last.querySelectorAll('img')].some(i=>visible(i)&&i.complete&&i.naturalWidth>=256):false;
   const delivered=(newer && (imgReady||lastAssets.some(x=>!x.startsWith('img:')))) || (newerAssistant&&imgReady&&lastAssets.length>0);
   return {delivered,active:stopVisible(),newerAssistant,assets:a.length};
 }
 function fill(el,value){
   el.focus();
   if(el.tagName==='TEXTAREA'){
     const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value')?.set;
     setter?setter.call(el,value):el.value=value;
     el.dispatchEvent(new InputEvent('input',{bubbles:true,data:value,inputType:'insertText'}));
   } else {
     const selection=window.getSelection(),range=document.createRange();
     range.selectNodeContents(el);range.collapse(false);selection.removeAllRanges();selection.addRange(range);
     el.replaceChildren();document.execCommand('insertText',false,value);
     el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));
   }
 }
 function compose(line,master){
   const k=line.indexOf('||'),label=k>=0?line.slice(0,k).trim():'',scene=k>=0?line.slice(k+2).trim():line;
   return [master,label?`Frame: ${label}`:'',`Scene: ${scene}`,'Generate exactly ONE individual 16:9 image. Do not make a multi-frame sheet.'].filter(Boolean).join('\n\n');
 }
 async function pause(error){await set({phase:'paused',error});stop();}
 function stop(){if(tickTimer)clearInterval(tickTimer);tickTimer=null;}
 async function step(){
   if(busy)return;busy=true;
   try{
     const s=await get();if(s.phase!=='running')return;
     const idx=s.index||0, prompts=s.prompts||[];
     if(idx>=prompts.length){await set({phase:'done',pending:null,error:''});stop();return}
     if(s.pending){
       const p=s.pending;
       const status=responseStatus(p);
       if(status.delivered&&!status.active){
         if(!p.stableSince){await set({pending:{...p,stableSince:Date.now()}});return}
         if(Date.now()-p.stableSince>=SETTLE_MS){
           await set({index:idx+1,pending:null,error:''});return;
         }
       }else if(p.stableSince){await set({pending:{...p,stableSince:null}})}
       if(Date.now()-p.sentAt>MAX_WAIT_MS){await pause(`Frame ${idx+1} was submitted but automatic image detection timed out. If the image is finished, use 'Mark current frame complete', then Resume. No prompt was resent.`)}
       return;
     }
     if(stopVisible())return;
     const e=editor();if(!e){await pause('ChatGPT prompt editor not found.');return}
     const text=compose(prompts[idx],s.master||'');
     // Persist the intent *before* clicking so a restart cannot duplicate it.
     const base=snapshot(), before=userNodes().length;
     await set({pending:{base,sentAt:Date.now(),stableSince:null,state:'submitting',prompt:text},error:''});
     fill(e,text);await sleep(600);
     let btn=null;
     for(let i=0;i<32;i++){btn=sendButton();if(btn)break;await sleep(250)}
     if(btn)btn.click();
     else {
       const form=e.closest('form');
       if(!form||typeof form.requestSubmit!=='function'){
         await pause('Send button unavailable. Prompt is pasted but not confirmed submitted. Do not Resume until you submit manually or Reset this frame.');return;
       }
       form.requestSubmit();
     }
     let confirmed=false;
     for(let i=0;i<40;i++){
       if(userNodes().length>before || userNodes().some(n=>(n.innerText||'').includes(text.slice(-80)))){confirmed=true;break}
       await sleep(350);
     }
     if(!confirmed){await pause('Could not confirm message submission. Check whether the frame was sent. Never automatically resending this frame.');return}
     await set({pending:{base,sentAt:Date.now(),stableSince:null,state:'waiting',prompt:text},error:''});
   }catch(err){await pause(`Queue paused: ${err.message}`)}finally{busy=false}
 }
 function run(){stop();tickTimer=setInterval(step,CHECK_MS);step()}
 chrome.runtime.onMessage.addListener(msg=>{
   (async()=>{
     if(msg.action==='START'){
       const s=await get();
       if(s.pending){await pause('An earlier frame is still pending. Use Resume to continue, or mark it complete after checking the image.');return}
       await set({phase:'running',error:''});run();
     }
     if(msg.action==='PAUSE'){await set({phase:'paused'});stop()}
     if(msg.action==='RESUME'){
       const s=await get();if(!s.prompts?.length){await pause('No saved prompts.');return}
       if(s.pending?.state==='submitting'){
         // Submission may have succeeded before an extension/tab reload.
         await pause('Submission status uncertain. Check chat; if image completed, mark frame complete. If not submitted, use Retry current frame.');return;
       }
       await set({phase:'running',error:''});run();
     }
     if(msg.action==='COMPLETE'){
       const s=await get();if(!s.pending){await pause('No pending frame to mark complete.');return}
       await set({index:(s.index||0)+1,pending:null,phase:'paused',error:'Frame marked complete. Press Resume for the next frame.'});stop();
     }
     if(msg.action==='RETRY'){
       const s=await get();if(!s.pending){await pause('No pending frame to retry.');return}
       await set({pending:null,phase:'paused',error:'Retry prepared. Press Resume to send this frame again. First confirm there is no existing generation.'});stop();
     }
     if(msg.action==='RESET'){await set({phase:'idle',index:0,pending:null,error:''});stop()}
   })().catch(console.error);
 });
 get().then(s=>{if(s.phase==='running')set({phase:'paused',error:'Tab or extension restarted. Press Resume; progress is preserved.'})});
})();
