const $=id=>document.getElementById(id);
const parse=s=>s.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
async function tab(){const [t]=await chrome.tabs.query({active:true,currentWindow:true});if(!t?.url||!/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(t.url))throw Error('Open the ChatGPT tab first.');return t}
async function send(action){const t=await tab();await chrome.tabs.sendMessage(t.id,{action})}
async function save(){const prompts=parse($('prompts').value);if(!prompts.length)throw Error('Add prompts first.');const d=await chrome.storage.local.get(['index','pending']);if(d.pending)throw Error('A frame is pending. Complete it or Reset first.');await chrome.storage.local.set({master:$('master').value.trim(),prompts,index:d.index||0,phase:'paused',error:'Queue saved. Progress preserved.',pending:null})}
async function op(fn){try{await fn()}catch(e){$('detail').textContent=e.message;return}await refresh()}
$('save').onclick=()=>op(save);
$('start').onclick=()=>op(async()=>{const d=await chrome.storage.local.get(['prompts']);if(!(d.prompts||[]).length)await save();await send('START')});
$('pause').onclick=()=>op(()=>send('PAUSE'));
$('resume').onclick=()=>op(()=>send('RESUME'));
$('complete').onclick=()=>op(()=>send('COMPLETE'));
$('retry').onclick=()=>op(()=>send('RETRY'));
$('reset').onclick=()=>op(()=>send('RESET'));
$('file').onchange=async e=>{const f=e.target.files?.[0];if(f)$('prompts').value=await f.text()};
async function refresh(){const d=await chrome.storage.local.get(['prompts','index','phase','error','pending']);const idx=d.index||0;$('status').textContent=d.phase||'idle';$('progress').textContent=`${idx} / ${(d.prompts||[]).length}`;$('detail').textContent=d.error|| (d.pending?`Frame ${String(idx+1).padStart(2,'0')} ${d.pending.state==='submitting'?'submitting':'waiting for image'} — Resume never resends it.`:`Next frame: ${idx+1}`)}
(async()=>{const d=await chrome.storage.local.get(['master','prompts']);$('master').value=d.master||'';$('prompts').value=(d.prompts||[]).join('\n');await refresh();setInterval(refresh,1300)})();
